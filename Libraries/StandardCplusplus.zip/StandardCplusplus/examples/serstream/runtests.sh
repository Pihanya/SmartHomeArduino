#!/bin/sh

jam u0 && expect test.ex 
